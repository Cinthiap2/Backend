package com.ecom.service;

import com.ecom.entity.UploadFileEntity;

public interface UploadFileService {
    UploadFileEntity addFileUpload(UploadFileEntity uploadFileEntity);
}
