package com.ecom.dto;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PortfolioRequestDto {
    private Long portfolioId;
}
